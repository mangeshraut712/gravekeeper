Gravekeeper restoration kit (esrever reverse() case 001)
Requires Node.js 22.18+. No install, no network.
  node scripts/verify-restoration.mts            # exit 0 when the restored version passes all fixtures
  node scripts/verify-restoration.mts --baseline # exit 1: the unchanged original fails new cases
Upstream: MIT, Mathias Bynens and contributors (third_party/esrever/upstream/LICENSE-MIT.txt).
Gravekeeper additions: MIT (LICENSE-GRAVEKEEPER-MIT).
